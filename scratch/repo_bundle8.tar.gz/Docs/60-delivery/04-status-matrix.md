# Implementation Status Matrix

> Status: **Living document.** Owner: Engineering lead.
> The single source for what is implemented, partial, pending, needs retesting, or blocked on a bank decision. Design lives in `10-architecture/` and `20-modules/`; material completion evidence is append-only in `06-accomplishment-log.md`.

**Last reviewed:** 2026-08-28

## Status definitions

| Status | Meaning |
|---|---|
| **Implemented** | Code, migration, API/runtime path, automated checks, and local end-to-end evidence exist |
| **Partial** | A safe production-oriented vertical slice exists, but named breadth or certification remains |
| **Pending** | Planned capability, not implemented |
| **Retest required** | Implemented locally but requires bank-scale, security, recovery, or target-environment certification |
| **Bank decision** | Must remain fail closed until an enterprise standard is supplied |

## Capability matrix

| Capability | Mod | Status | Implemented now | Remaining or next evidence |
|---|:--:|---|---|---|
| Organization / LOB / project tenancy | 01 | Implemented | Stable hierarchy, organization enforcement, paginated tenant inventory, guided onboarding, audit and outbox evidence | Enterprise legal-entity and entitlement feeds; bulk onboarding |
| Enterprise authentication | 01 | Partial | Signed OIDC/JWKS verification — issuer, audience, time, algorithm; JWKS cache/refresh; pinned keys; configurable claim paths and role mapping; local identity is development-only | Bank issuer/claims/groups certification; workload identity; revocation/replay policy; break-glass |
| Enterprise secrets and source identity | 01 | Partial | Inline secrets rejected; one configured provider scheme; provider-neutral adapter contract; strict reference parsing; bounded cache with rotation invalidation; production rejects `env://` | Register and certify the bank adapter; workload identity; rotation/outage drills; delegated read-only source identities |
| Source registry and ingestion | 02, 03 | Partial | Registration, secret references, capability negotiation, source operations; envelope `1.0` with atomic synchronous ingestion; persisted idempotent manifests/chunks; Temporal retries/heartbeats; cross-chunk FK resolution; deferred FULL reconciliation; payload cleanup; full Atlas workbench | Bulk onboarding; signed producers; Kafka/schema registry; pause/cancel; admission quotas; explicit replay tooling; maximum-scale recovery certification |
| PostgreSQL connector | 02 | Implemented for the current contract | Discovery, read-only execution, EXPLAIN cost, timeouts, bounded profiling, capability/version definition, deterministic per-source conformance evidence | Version fixtures; load/cancellation/recovery certification; delegated identity |
| Microsoft SQL Server connector | 02 | Partial (`BETA`) | Real Docker fixture passing connectivity, exact 4/22/7 discovery, bounded profiling, database-scoped SHOWPLAN cost, governed query/masking, 100-point certification | Multi-version, TLS/private-network, delegated-identity, load, cancellation, recovery certification |
| Oracle connector | 02 | Partial (`BETA`, unverified live) | Native async adapter (`python-oracledb` thin mode), canonical DSN parsing, `ALL_TAB_COLUMNS`/`ALL_CONSTRAINTS` discovery reusing shared helpers, real session-ID capture, LOB-aware bounded profiling, compose fixture | Live container verification; certified least-privilege `PLAN_TABLE` path before enabling EXPLAIN (currently fails closed with `QUERY_ESTIMATE_UNAVAILABLE_FOR_CONNECTOR`) |
| BigQuery connector | 02 | Partial (`BETA`, unverified live) | Native pull adapter with a single structured service-account/workload-identity credential shape (no fake DSN), GCP project→catalog and dataset→schema mapping, `INFORMATION_SCHEMA`-based discovery with honest foreign-key omission, dry-run byte estimate feeding a new connector-agnostic byte-budget gate in the query gateway, bounded profiling with explicit byte/row/timeout limits | Live GCP project verification; certification; version fixtures |
| Snowflake connector | 02 | Partial (`BETA`, unverified live) | Native pull adapter with JSON-or-URI credential parsing, multi-database `INFORMATION_SCHEMA` discovery via shared assembly helpers, partition-pruned `EXPLAIN USING JSON` cost estimation, `APPROX_COUNT_DISTINCT` bounded profiling, real warehouse query-ID (`sfqid`) capture | Live account/warehouse verification; certification; version fixtures |
| Other connectors | 02 | Pending | Databricks, Teradata, Db2 are visibly `PLANNED` (canonical push ingestion only; no native pull adapter) | Implement and certify in bank priority order |
| Connector certification | 02 | Implemented for control-plane conformance | Immutable certification runs scoring implementation, secret reference, connection, hierarchy capability, inventory, canonical push evidence; capability/maturity/transport matrix with drill-down | Executable vendor/version fixtures; source-side agents; load, retry, cancellation, least-privilege, recovery packs |
| Catalog inventory | 04 | Implemented | Catalog/schema/table/view/column/constraint with stable identity, fingerprints, drift counts, tombstones, reactivation | Index/partition models; bulk actions; virtualization; rename detection |
| Safe profiling | 05 | Implemented | Table estimates and value-free null/distinct/length statistics with sampling and hard bounds | Policy-approved ranges/top-values by classification; freshness-relevant profiling |
| Classification | 05 | Implemented | Deterministic rules with evidence and algorithm version | Authoritative external classification feed |
| Durable analysis workflow | 05 | Implemented | Temporal discovery plus independently retryable table-task DAG with heartbeats, cancellation, resume | Continue-as-new at maximum source scale |
| Fleet scheduling | 03 | Implemented | HA-safe policy polling, priority, maintenance windows, organization quotas, per-source admission, backpressure | Fairness and capacity testing across thousands of sources |
| Schema drift / reconciliation | 04 | Implemented | Created/changed/deprecated evidence, soft deprecation, reactivation, graph lag summary | Enterprise notification and retention policy |
| Declared PK/FK graph | 06, 10 | Implemented | Constraint inventory and Neo4j FK relationships | Projection performance at millions of nodes |
| Inferred relationships | 06 | Partial | Bounded metadata-only candidates, enriched named edges, confidence/evidence, durable review, negative knowledge; Graph Explorer V2 with server-side search, 1–4 hop directional traversal, policy caps, truncation reasons, evidence inspection | Composite candidates; statistical evidence policy; projection of approvals to Neo4j; cross-source traversal; million-node rendering certification |
| Temporal / table-family intelligence | 06 | **Pending** | Architecture and evidence model documented | History/snapshot/delta/SCD inference and canonical-table review |
| SQL / query lineage | 09 | Partial | Durable referenced tables/columns, value-free SELECT output-to-source mappings, direct/derived classification, transformation names, governed-tool dependencies, API and Atlas visibility; OpenLineage run-event ingestion producing table- and column-level edges via a mounted API (`openlineage.py`/`openlineage_api.py`), untested and unverified against a real Airflow-sourced event | View/procedure lineage; OpenLineage test coverage and Airflow-sourced e2e evidence; warehouse history adapters |
| dbt transformation intelligence | 09 | Partial | Governed project registration, immutable manifest v12-compatible ingestion, model/source/test inventory, catalog matching, SQL hash plus literal-redacted SQL, dependency DAG, impact, agent retrieval, Atlas workbench; `run_results.json` ingestion driving test-status/failure evidence and automatic data-quality-incident open/resolve reconciliation (`dbt_quality_bridge.py`) | CI/dbt Cloud auth; column-level lineage; retention; large-DAG virtualization |
| Impact analysis | 09 | Implemented | Physical table to semantic metrics, governed tools, approved relationship evidence | Transitive graph traversal; ETL dependencies |
| Business-semantic inference | 07 | Implemented for the metadata-structure slice | Bounded deterministic plus optional approved-LLM proposals for domains, entities, descriptions, table roles, grain, synonyms, questions, safe tool blueprints; metadata-only evidence; strict schema validation; maker-checker; authoritative annotations; cross-domain FK map | Inferred glossary binding; ambiguity/conflict resolution; confidence calibration; bank-domain evaluation corpus |
| Semantic models and metrics | 07 | Partial | Versioned metrics with grain/time/physical mappings, maker-checker publication, supersession, clone rollback | Governed dimensions; glossary binding; conflicts; metric suggestions from annotations |
| Glossary and stewardship | 08 | Implemented for the governed table-stewardship slice | Categories; immutable term definitions/synonyms; maker-checker publication, supersession and deprecation; manual/bulk/inferred links with provenance; individual/group and rule ownership; retained conflict resolution; expiring certification; six-dimension organization/source/domain/LOB coverage with snapshots; bounded unowned backlog; responsive control-center UI | Category administration; inheritance/leaver workflow; automatic certification-expiry events; fuzzy inference calibration; scheduled routing/trends; additional asset types; bank-scale and interactive accessibility certification |
| Hybrid retrieval | 12 | Partial | Organization/source-scoped lexical ranking across active tables, columns, approved annotations, published metrics, published tools, latest dbt artifacts; bounded evidence and selection reasons; policy filtering before ranking | Full-text index; vector projection; graph expansion; fusion ranking; large-catalog benchmarks |
| Agent orchestration | 13 | Partial | Framework-neutral typed states including a pre-retrieval `SCREENED` gate; versioned deterministic prompt-risk classifier blocking instruction override, prompt/credential extraction, policy/masking bypass, privilege escalation, unbounded extraction; governed retrieval; approved-tool-first execution; bounded grounding; OpenAI/Gemini structured output; semantic/policy pinning; value-free trace and plan evidence | Multi-step tool plans; indirect-injection defences; multilingual/obfuscation coverage; retrieval/model benchmarks; bank model-risk corpus |
| Query execution gateway | 16 | Implemented | SQLGlot AST validation, allowlists, EXPLAIN/cost, read-only timeout, masking, redaction, HMAC evidence | Source-native row/column policies; cancel propagation certification; per-LOB quotas |
| Query memory | 13 | Partial | Value-free, semantic-version-aware evidence and feedback suppression | Similarity retrieval; safe adaptation; usage scoring; benchmark |
| Governed tools | 14 | Implemented | Versioning, strict parameter schemas, AST literal binding, RBAC, maker-checker publish/deprecate, audited execution, retrieval ranking, tool-first agent binding | Formal certification corpus; multi-tool plans; quality gating |
| Model route and AI governance | 15 | Partial | Immutable route versions with residency/retention/capability/budget contracts; credential-reference redaction; maker-checker lifecycle; honest activation states; OpenAI Responses and Gemini adapters with structured output, bounded retries/timeouts, non-content evidence; durable evaluations | Rotated credentials; bank-approved route selection; private routing/workload identity; retention certification; model-risk corpus; monitoring; **kill-switch drill** |
| Data-quality observability | 11 | Implemented for profile-baseline controls | Source/table policies; deterministic volume, null-rate, schema-fingerprint comparison; immutable value-free observations; fingerprinted incident lifecycle with auto-recovery; audited acknowledge/resolve; metadata scan-age posture; automatic Temporal integration; Atlas investigation workspace | Approved watermark contracts for freshness; rule scheduling beyond scans; notification routing; SLOs; bank-scale incident certification; **runtime coupling** |
| Policy and governance | 17 | Partial | RBAC role gates, organization enforcement, unified cross-object review queue with filters, rationale capture, independent decisions, platform-enforced maker≠checker | ABAC; purpose-based access; agent-vs-human context; bulk decisions; delegation; entitlements; full decision logging |
| Audit and event delivery | 20 | Implemented | Attributable audit ledger, transactional outbox, idempotent publication, retry/backoff, dead-letter, authorized requeue | WORM archive; retention; SIEM/SOC routing; OpenTelemetry; access review |
| Context products and MCP | 19 | Partial | Real JSON-RPC 2.0 MCP endpoint (`POST /mcp`): `initialize`/`ping`/`tools.list`/`tools.call`/`resources.list`/`resources.read`; tool exposure and invocation are role-filtered and route through the same governed orchestrator/query-gateway stack as the native REST path, denying ineligible tools without leaking their existence, with audit/outbox evidence | Context products with maker-checker (CX-2); per-read policy evaluation and consumption-lineage edges for `resources/read` (CX-3/CX-4); per-consumer budgets (CX-6); `prompts/*` handlers |
| Studio | 18 | **Pending** | Form-based authoring exists in the portal (metric composer, tool authoring) | Change sets, test harness, diff view, parameter designer, Git binding |
| Agentic product portal | 21 | Implemented for current API scope | Role-oriented product at port 3000: asset-first shell and explorer; tabbed asset workspace; glossary term authoring/review; versioned aliases/README ownership and approved term linking; analyst workflow, catalog/impact, dbt transformations, business meaning, semantics, tools, graph, model routes, sources, quality, operations, governance and audit; ARIA roles/labels, roving-tabindex tab/command-palette keyboard navigation, focus management and restoration, live-region status/error announcements, `prefers-reduced-motion` support and a verified body-text contrast fix | Persona bound to OIDC groups; interactive screen-reader/axe-core WCAG AA accessibility certification; million-node visual certification |
| Production platform / network | — | **Bank decision** | Reproducible local Docker engineering topology | Kubernetes/managed services, regions, private endpoints, mTLS, egress, residency |
| DR and continuity | — | **Bank decision** | Durable local service volumes | Approved RPO/RTO, backup/restore, failover, regional recovery exercises |
| Performance / security / recovery certification | — | **Retest required** | Unit, strict type, migration drift, and local end-to-end suites pass | Load, soak, chaos, penetration, SAST/DAST, restore, connector certification |

## Retest register

| Test area | Local result | Required next run |
|---|---|---|
| Static quality | Ruff and strict mypy clean | CI on every change |
| Unit / contract suite | 121 tests passing — SQL Server and canonical/chunk contract validation, stable checksums, sequence/duplicate rejection, scope counting, quality, prompt-risk, graph, business inference, model, dbt, OIDC, secret, lineage, tool-first, evaluation controls | Add database concurrency/race tests, forced mid-batch restart, incident concurrency, JWKS outage, indirect prompt attacks, bank-domain benchmarks |
| Database migrations | Alembic head `9e4c7a12b5f8`, single head, applied locally | Upgrade/rollback rehearsal on production-like data |
| End-to-end banking fixture | R20/R21/R22 real API/Temporal/PostgreSQL runs proved manifest/chunk replay, conflicting-content denial, cross-chunk FK resolution, exact scope counts, physical payload cleanup, live SQL Server discovery/profiling/SHOWPLAN/masking | FULL retirement/recovery and concurrent forced-restart fixtures; Kafka intake; maximum-scale load; remaining connectors; approved-provider certification; interactive visual/accessibility certification |
| Security | Fail-closed controls and cross-tenant denial pass locally | Threat-led penetration testing; ABAC/row-policy certification |
| Recovery | Component retries exercised | Full PostgreSQL/Temporal/Kafka/Neo4j restore and regional failover drill |
| Performance | **Not measured** | Load, soak, spike, projection rebuild timing, PITR restore |

## Reading the matrix

Three patterns are worth naming:

1. **The control plane is strong; the operational evidence is absent.** Everything in the "Implemented" column has local end-to-end evidence and nothing has bank-scale evidence. That gap is Phase D.
2. **One module is entirely pending** — studio (18). Glossary (08) now implements the governed table-stewardship slice; context products and MCP (19) now implements a governed MCP tool surface; broader asset types, operational automation, and bank-scale certification remain for both.
3. **Several "Partial" rows are partial in the same way**: the safe slice exists, the breadth does not. Connectors, retrieval, lineage, and policy all follow this shape, which is a deliberate consequence of building vertically rather than broadly.

## Related documents

- Tracker: `60-delivery/03-tracker.md`
- Gap register: `60-delivery/05-gap-register.md`
- Accomplishment log: `60-delivery/06-accomplishment-log.md`
- ADR register: `10-architecture/adr/README.md`
