"""Bank Data Intelligence Platform control plane."""

__version__ = "0.1.0"
