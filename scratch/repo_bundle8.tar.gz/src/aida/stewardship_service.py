from datetime import UTC, datetime
from uuid import UUID

from fastapi import HTTPException
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from aida.models import (
    AssetCertification,
    AssetTermLink,
    BulkStewardshipOperation,
    GlossaryConflict,
    GlossaryLinkProposal,
    GlossaryTerm,
    GlossaryTermVersion,
    OwnershipAssignment,
)
from aida.schemas import CoverageDimensionRead, StewardshipCoverageRead

COVERAGE_DIMENSIONS = (
    "documented",
    "owned",
    "classified",
    "certified",
    "quality_monitored",
    "semantically_mapped",
)


def build_stewardship_coverage(
    *,
    organization_id: UUID,
    datasource_id: UUID | None,
    domain_id: UUID | None,
    line_of_business_id: UUID | None,
    table_ids: set[UUID],
    evidence_sets: dict[str, set[UUID]],
    computed_at: datetime,
) -> StewardshipCoverageRead:
    """Compute the six-dimensional score from bounded, table-level evidence."""
    total = len(table_ids)
    dimensions: dict[str, CoverageDimensionRead] = {}
    for name in COVERAGE_DIMENSIONS:
        covered = len(evidence_sets.get(name, set()) & table_ids)
        dimensions[name] = CoverageDimensionRead(
            covered=covered,
            total=total,
            percentage=round(covered * 100 / total, 2) if total else 0.0,
        )
    overall = (
        round(sum(dimension.percentage for dimension in dimensions.values()) / len(dimensions), 2)
        if total
        else 0.0
    )
    owned = evidence_sets.get("owned", set())
    return StewardshipCoverageRead(
        organization_id=organization_id,
        datasource_id=datasource_id,
        domain_id=domain_id,
        line_of_business_id=line_of_business_id,
        table_count=total,
        overall_score=overall,
        dimensions=dimensions,
        unowned_table_ids=sorted(table_ids - owned, key=str)[:500],
        computed_at=computed_at,
    )


def active_certified_table_ids(
    certifications: list[AssetCertification], *, now: datetime
) -> set[UUID]:
    """Table IDs whose certification is currently ACTIVE and not expired.

    Certification is a time-bound attestation, not a permanent one: a certification
    that has passed its ``expires_at`` must stop counting toward the "certified"
    stewardship-coverage dimension even though its ``status`` row hasn't separately
    been flipped -- expiry, not just status, gates whether it still counts.
    """
    return {
        certification.table_id
        for certification in certifications
        if certification.status == "ACTIVE" and certification.expires_at > now
    }


async def apply_bulk_operation(
    session: AsyncSession,
    operation: BulkStewardshipOperation,
    *,
    reviewer: str,
    now: datetime,
) -> tuple[str, int]:
    applied = 0
    parameters = operation.parameters
    subject_ids = [UUID(value) for value in operation.subject_ids]
    if operation.operation_type == "ASSIGN_OWNERSHIP":
        for subject_id in subject_ids:
            existing = await session.scalar(
                select(OwnershipAssignment).where(
                    OwnershipAssignment.organization_id == operation.organization_id,
                    OwnershipAssignment.subject_type == operation.subject_type,
                    OwnershipAssignment.subject_id == str(subject_id),
                    OwnershipAssignment.owner_type == parameters["owner_type"],
                    OwnershipAssignment.owner_principal == parameters["owner_principal"],
                )
            )
            if existing is not None:
                if existing.status != "ACTIVE":
                    existing.status = "ACTIVE"
                    existing.assigned_by = reviewer
                    applied += 1
                continue
            session.add(
                OwnershipAssignment(
                    organization_id=operation.organization_id,
                    subject_type=operation.subject_type,
                    subject_id=str(subject_id),
                    owner_type=parameters["owner_type"],
                    owner_principal=parameters["owner_principal"],
                    assignment_kind="RULE" if parameters.get("source_rule_id") else "MANUAL",
                    source_rule_id=(
                        UUID(parameters["source_rule_id"])
                        if parameters.get("source_rule_id")
                        else None
                    ),
                    assigned_by=reviewer,
                )
            )
            applied += 1
        event_type = "ownership.assigned.v1"
    elif operation.operation_type == "LINK_TERM":
        term_id = UUID(parameters["term_id"])
        for table_id in subject_ids:
            existing = await session.scalar(
                select(AssetTermLink).where(
                    AssetTermLink.table_id == table_id,
                    AssetTermLink.term_id == term_id,
                )
            )
            if existing is not None:
                continue
            session.add(
                AssetTermLink(
                    organization_id=operation.organization_id,
                    table_id=table_id,
                    term_id=term_id,
                    linked_by=reviewer,
                    link_type="BULK",
                    confidence=1.0,
                )
            )
            applied += 1
        event_type = "glossary.term_linked_bulk.v1"
    elif operation.operation_type == "DEPRECATE_TERM":
        terms = (
            await session.scalars(
                select(GlossaryTerm).where(
                    GlossaryTerm.organization_id == operation.organization_id,
                    GlossaryTerm.id.in_(subject_ids),
                )
            )
        ).all()
        for term in terms:
            if term.lifecycle_status == "DEPRECATED":
                continue
            term.lifecycle_status = "DEPRECATED"
            term.deprecated_by = reviewer
            term.deprecated_at = now
            term.deprecation_reason = parameters["rationale"]
            await session.execute(
                update(GlossaryTermVersion)
                .where(
                    GlossaryTermVersion.term_id == term.id,
                    GlossaryTermVersion.status == "APPROVED",
                )
                .values(status="DEPRECATED", updated_at=now)
            )
            applied += 1
        event_type = "glossary.term_deprecated.v1"
    elif operation.operation_type == "CERTIFY_ASSET":
        expires_at = datetime.fromisoformat(parameters["expires_at"])
        for table_id in subject_ids:
            await session.execute(
                update(AssetCertification)
                .where(
                    AssetCertification.table_id == table_id,
                    AssetCertification.status == "ACTIVE",
                )
                .values(status="SUPERSEDED", updated_at=now)
            )
            session.add(
                AssetCertification(
                    organization_id=operation.organization_id,
                    table_id=table_id,
                    rationale=parameters["rationale"],
                    certified_by=reviewer,
                    expires_at=expires_at,
                )
            )
            applied += 1
        event_type = "certification.granted.v1"
    else:
        raise HTTPException(status_code=422, detail="unsupported stewardship operation")
    operation.status = "APPLIED"
    operation.applied_by = reviewer
    operation.applied_at = now
    operation.applied_count = applied
    return event_type, applied


async def apply_conflict_resolution(
    conflict: GlossaryConflict,
    *,
    reviewer: str,
    now: datetime,
) -> str:
    if conflict.status != "REVIEW_REQUIRED":
        raise HTTPException(status_code=409, detail="conflict is no longer pending review")
    conflict.status = "RESOLVED"
    conflict.resolved_by = reviewer
    conflict.resolved_at = now
    return "glossary.conflict_resolved.v1"


async def reject_conflict_resolution(conflict: GlossaryConflict) -> str:
    if conflict.status != "REVIEW_REQUIRED":
        raise HTTPException(status_code=409, detail="conflict is no longer pending review")
    conflict.status = "OPEN"
    conflict.proposed_resolution = None
    conflict.proposed_definition = None
    conflict.resolution_rationale = None
    return "glossary.conflict_resolution_rejected.v1"


async def apply_link_proposal(
    session: AsyncSession,
    proposal: GlossaryLinkProposal,
    *,
    reviewer: str,
    now: datetime,
) -> str:
    if proposal.status != "REVIEW_REQUIRED":
        raise HTTPException(status_code=409, detail="link proposal is no longer pending review")
    existing = await session.scalar(
        select(AssetTermLink).where(
            AssetTermLink.table_id == proposal.table_id,
            AssetTermLink.term_id == proposal.term_id,
        )
    )
    if existing is None:
        session.add(
            AssetTermLink(
                organization_id=proposal.organization_id,
                table_id=proposal.table_id,
                term_id=proposal.term_id,
                linked_by=reviewer,
                link_type="INFERRED",
                confidence=proposal.confidence,
                source_annotation_id=proposal.source_annotation_id,
            )
        )
    proposal.status = "APPROVED"
    proposal.reviewed_by = reviewer
    proposal.reviewed_at = now
    return "glossary.link_proposal_approved.v1"


async def reject_link_proposal(
    proposal: GlossaryLinkProposal,
    *,
    reviewer: str,
    now: datetime,
) -> str:
    if proposal.status != "REVIEW_REQUIRED":
        raise HTTPException(status_code=409, detail="link proposal is no longer pending review")
    proposal.status = "REJECTED"
    proposal.reviewed_by = reviewer
    proposal.reviewed_at = now
    return "glossary.link_proposal_rejected.v1"


def utc_now() -> datetime:
    return datetime.now(UTC)
